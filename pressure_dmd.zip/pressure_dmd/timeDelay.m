function H=timeDelay(X,p) 
% Construction of the Hankel matrix for the embedded time delay.
% X is the snapshot data matrix, and p the number of time delays. 
[n,m]=size(X); 
H=[]; 
for j = 1:p 
H = [H ; X(:,j:j-p+end)]; 
end 
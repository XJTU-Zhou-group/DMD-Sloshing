function [Phi lambda] = computeDMD(Data,r) 
% Compute DMD - Code adapted from JKutz, S.Brunton, B.Brunton, 
% and J.Proctor (Dynamic Mode Decomposition) 
X = Data(:,1:end-1); 
X2 = Data(:,2:end); 
[U,S,V] = svd(X,'econ'); 
% Compute DMD (Phi are eigenvectors) 
U = U(:,1:r); 
S = S(1:r,1:r); 
V = V(:,1:r); 
Atilde = U'*X2*V*pinv(S); 
[W,eigs] = eig(Atilde); 
Phi = X2*V*pinv(S)*W; 
lambda = diag(eigs);
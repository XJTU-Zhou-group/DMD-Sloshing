function y_dmd=time_series(Phi,lambda,z0,t) 
% reconstruction of the dynamical system from eigenvalues (lambda) 
% and eigenvectors (phi), with z0=Phi\x0, and t the vector time 
% x(t)=Phi*exp(omega*t)*z0 
dt=t(2)-t(1); % time step 
% frequency in continuos space 
omega=log(lambda)/dt; 
r_ord=length(Phi(1,:)); 
% Reconstruction of time series from eigenpairs 
time_dynamics=zeros(r_ord,length(t)); 
for iter=1:length(t) 
time_dynamics(:,iter)=z0.*(exp(omega*t(iter))); 
end 
y_dmd=Phi*time_dynamics;
clear
clc
A=importdata('p1-rfile.out');
data=A.data;
p1=data(:,2)';
t=data(:,3)';

p1_1=p1(:,1:5001);
t_1=t(:,1:5001);


p=3000; % number of time delays 
H=timeDelay(p1_1,p); 
r=1500;
% r = reduced_form(H,.999); % tolerance can be adjusted 
[Phi,lambda] = computeDMD(H,r); 
H1=H(:,1); % Initial condition 
z0 = Phi\H1; 
p1_dmd =time_series(Phi,lambda,z0,t);

p1_DMD=real(p1_dmd(1,:));

A=importdata('p2-rfile.out');
data=A.data;
p2=data(:,2)';


p2_1=p2(:,1:5001);
t_1=t(:,1:5001);


p=3000; % number of time delays 
H=timeDelay(p2_1,p); 
r=1500;
% r = reduced_form(H,.999); % tolerance can be adjusted 
[Phi,lambda] = computeDMD(H,r); 
H1=H(:,1); % Initial condition 
z0 = Phi\H1; 
p2_dmd =time_series(Phi,lambda,z0,t);

p2_DMD=real(p2_dmd(1,:));

A=importdata('p3-rfile.out');
data=A.data;
p3=data(:,2)';

p3_1=p3(:,1:5001);
t_1=t(:,1:5001);


p=3000; % number of time delays 
H=timeDelay(p3_1,p); 
r=1500;
% r = reduced_form(H,.999); % tolerance can be adjusted 
[Phi,lambda] = computeDMD(H,r); 
H1=H(:,1); % Initial condition 
z0 = Phi\H1; 
p3_dmd =time_series(Phi,lambda,z0,t);

p3_DMD=real(p3_dmd(1,:));
%%
figure(1)
plot(t,p1_DMD,'r','linewidth',1.5);
hold on
plot(t,p1,'-.','linewidth',1.5);

figure(2)
plot(t,p2_DMD,'r','linewidth',1.5);
hold on
plot(t,p2,'-.','linewidth',1.5);

figure(3)
plot(t,p3_DMD,'r','linewidth',1.5);
hold on
plot(t,p3,'-.','linewidth',1.5);

P1=p1_DMD';
P2=p2_DMD';
P3=p3_DMD';
p1=p1';
p2=p2';
p3=p3';

% for i=1:10:6001
%     T_check1(nn,1)=T_check(i,1);
%     t_check(nn,1)=(nn-1)*0.0082/20;
%     nn=nn+1;
% end
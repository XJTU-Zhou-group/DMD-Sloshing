clear
clc

%%
x(1:401) = linspace(-0.6,0.6,401);
y(1:201) = linspace(0.3,-0.3,201);
for i = 1:1:201
    xq(i,:) = x(1:401);
end
for i = 1:1:401
    yq(:,i) = y(1:201);
end
%%
for i=10:10:3920
    if i<100
        name=['outpf1f2-00',num2str(i)];
    elseif i<1000
        name=['outpf1f2-0',num2str(i)];
    else
        name=['outpf1f2-',num2str(i)];
    end
    a=importdata(name);
    eval(['DATA_',num2str((i-10)/10+1),' = a.data;']);
end
%%
for i = 1:1:392
     eval(['p_',num2str(i),' = griddata(DATA_',num2str(i),'(:,2),DATA_',num2str(i),'(:,3),DATA_',num2str(i),'(:,4),xq,yq);'])
end
for i = 1:1:392
    eval(['v1_',num2str(i),' = griddata(DATA_',num2str(i),'(:,2),DATA_',num2str(i),'(:,3),DATA_',num2str(i),'(:,5),xq,yq);'])
end
for i = 1:1:392
    eval(['v2_',num2str(i),' = griddata(DATA_',num2str(i),'(:,2),DATA_',num2str(i),'(:,3),DATA_',num2str(i),'(:,6),xq,yq);'])
end   

%%
for i = 1:1:392
    eval(['p(:,i) = reshape(p_',num2str(i),',1,[]);'])
    eval(['v1(:,i) = reshape(v1_',num2str(i),',1,[]);'])
    eval(['v2(:,i) = reshape(v2_',num2str(i),',1,[]);'])
end
save('p.mat','p');
save('v1.mat','v1');
save('v2.mat','v2');
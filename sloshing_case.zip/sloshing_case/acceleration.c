# include "udf.h"
DEFINE_SOURCE(mom_sources,c,t,ds,eqn)
{
	real source,keep_time;
	keep_time=CURRENT_TIME;
	if(keep_time<10) 
	{
		source=-0.78237*sin(3.1415926*2*0.5747126437*keep_time)*C_R(c,t);
		ds[eqn]=-0.78237*sin(3.1415926*2*0.5747126437*keep_time);
	}
	else
	{
		source=0;
		ds[eqn]=0;
	}
	return source;
}
